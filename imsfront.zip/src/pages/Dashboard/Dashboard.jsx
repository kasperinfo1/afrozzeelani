// import React from 'react';

// const Dashboard =() =>{


//     return(
//         <>
//         <h1>afroz</h1>
//         </>
//     )
// }

// export default Dashboard

import React from 'react';
// import './Dashboard.css'; // For custom styles (if any)
import { Link } from 'react-router-dom'; // Use React Router for navigation

const Dashboard = () => {
  const options = [
    { name: 'Purchase', icon: 'fas fa-shopping-cart', link: '/purchase' },
    { name: 'Suppliers', icon: 'fas fa-user-tie', link: '/suppliers' },
    { name: 'Tax', icon: 'fas fa-receipt', link: '/tax' },
    { name: 'Vendors', icon: 'fas fa-store', link: '/vendors' },
    { name: 'Profile', icon: 'fas fa-user-circle', link: '/profile' },
    { name: 'Sell', icon: 'fas fa-fire-alt', link: '/sell' },
    { name: 'Products', icon: 'fas fa-box-open', link: '/products' },
    { name: 'Customer', icon: 'fas fa-user-plus', link: '/customer' },
    { name: 'Stock', icon: 'fas fa-warehouse', link: '/stock' },
    { name: 'Profit', icon: 'fas fa-chart-line', link: '/profit' }
  ];

  return (
    <div className="dashContainer mt-4" >

      {/* Options Grid */}
      <div className="row text-center g-4">
        {options.map((option, index) => (
          <div key={index} className="col-6 col-md-4 col-lg-3">
            <Link to={option.link} className="text-decoration-none">
              <div className="card shadow-sm border-0 h-100">
                <div className="card-body d-flex flex-column justify-content-center align-items-center">
                  <i className={`${option.icon} fa-3x mb-3`} style={{ color: '#17a2b8' }}></i>
                  <h5 className="card-title">{option.name}</h5>
                </div>
              </div>
            </Link>
          </div>
        ))}
      </div>

      {/* Terms and Conditions */}
      <div className="mt-5">
        <h4>Terms & Conditions</h4>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque sit
          amet accumsan arcu. Nulla facilisi. Nam eget aliquam ligula. Nullam
          posuere faucibus leo, in placerat nulla gravida at. Fusce efficitur
          vehicula est, ut pretium sapien efficitur nec.
        </p>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris
          rhoncus pharetra pharetra. Cras dictum felis sit amet orci feugiat,
          et condimentum purus mattis.
        </p>
      </div>
    </div>
  );
};

export default Dashboard;



